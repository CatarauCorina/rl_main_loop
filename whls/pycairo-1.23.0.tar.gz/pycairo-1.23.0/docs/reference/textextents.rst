.. _textextents:

***********
TextExtents
***********

.. currentmodule:: cairo

class TextExtents(tuple)
========================

.. autoclass:: TextExtents
    :members:
    :undoc-members:

    .. automethod:: __init__