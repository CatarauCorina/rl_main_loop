.. _glyph:

*****
Glyph
*****

.. currentmodule:: cairo

class Glyph(tuple)
==================

.. autoclass:: Glyph
    :members:
    :undoc-members:

    .. automethod:: __init__