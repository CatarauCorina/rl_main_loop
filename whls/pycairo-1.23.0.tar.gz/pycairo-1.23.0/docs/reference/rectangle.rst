.. _rectangle:

*********
Rectangle
*********

.. currentmodule:: cairo

class Rectangle(tuple)
======================

.. autoclass:: cairo.Rectangle
    :members:
    :undoc-members:

    .. automethod:: __init__