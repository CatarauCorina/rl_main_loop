.. _devices:

*******
Devices
*******

.. currentmodule:: cairo


class Device()
===============

.. autoclass:: Device
    :members:
    :undoc-members:


class ScriptDevice(:class:`Device`)
===================================

.. autoclass:: ScriptDevice
    :members:
    :undoc-members:

    .. automethod:: __init__
