========
Examples
========

The Git repository and release tarball contain various examples showing
various features of cairo and integration with pygame and GTK+ in the
"examples" directory:

    https://github.com/pygobject/pycairo/tree/master/examples
