from .EasyTensorBoard import EasyTensorBoard
